/* sum up integers form 1 to 100 */


int i, sum;

main() {
	sum = 0;
	for(i=0; i<=100; i++){
		sum = sum + i;
	}

  	cout << sum;
}

