/* prompts the user to enter a positive integer n, and then calculate the value of n factorial n! = multiplication of all integers between 1 and n, and print the value n! on the screen. */


int i, n;
int multiplication;

main() {
	cout << "Please input a positive integer n: ";
	cin >> n;
	while (n<=0){
		cout << "Please input an integer bigger than 0, try agiain:";
		cin >> n;
	}
	
	multiplication = 1;
	for(i=1; i<=n; i++){
		multiplication = multiplication * i;
	}

	cout << "The value of ";
	cout << n;
	cout << "! is ";
	cout <<multiplication;
	cout <<".";
		
}

